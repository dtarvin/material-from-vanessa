 function simpleSlider(element = '#simple-slider', auto = false, pause) {
     //Get parent element
     var $this = $(element);
    
    //slides container
    var slideCont = this.children('.slides-container');

    //Get all slides
    var slides = slideCont.children('slide');

    //Get pager div 
    var pager = $this.children('.pager');

    //get previous /next links
    var arrowsCont = $this.children('.arrows');
    var prevSlide = arrowsCont.children('.prev');
    var nextSlide = arrownCont.children('.next');

    //total slides count
    var slidesCount = slides.length;

    //set currentSlide to first child
    var currentSlide = slides.first
    var currentSlideIndex = 1;

    var autoPlay = null;

    //hide all slides except for the first one and add active class to first
    slides.not(':first').css('display', 'none');
    currentSlide.addClass('active');

    //function responsibility for fading to previous slide
    function fadeNext() {
        currentSlide.removeClass('active').fadeOut(700);

        if(currentSlideIndex == slideCount){
            currentSlide = slides.first();
            currentSlide.delay(500).addClass('active').fadeIn(700);
            currentSlideIndex = 1;
        } else {
            currentSlideIndex ++;
            currentSlide = currentSlide.next();
            currentSlide.delay(300).addClass('active').fadeIn(700);
        }
    pager.text(currentSlideIndex + ' / ' + slideCount);
    }

    function fadePrev() {
        currentSlide.removeClass('active').fadeOut(700);
            if(currentSlideIndex == 1){
                 currentSlide = slides.last();
                 currentSlide.delay(500).addClass('active').fadeIn();
                 currentSlideIndex = slideCount;
        } else {
            currentSlideIndex --;
            currentSlide = currentSlide.prev();
            currentSlide.delay(300).addClass('active').fadeIn(700);
        }
    pager.text(currentSlideIndex + ' / ' + slideCount);
    }

    //function that starts the autoplay and it resets it in case the user navigates (clicks) next or prev arrow button
    function AutoPlay() {
        clearInterval(autoPlay);
         if(auto == true)
            autoPlay = setInterval(function() {fadeNext() }, pause);
    }
    //dectect if a user clicked on the arrow for next slide and fade next slide if it did
    $(nextSlide).click(function(e){
        e.preventDefault();
        fadePrev();
        AutoPlay();
    });

    //detect if the user clicked on the prev arrow and fade slide if it did
    $(prevSlide).click(function(e){
        e.preventDefault();
        fadePrev();
        AutoPlay();
    });

    //start autoplay is autp is set to true
    AutoPlay();

    $(function(){
            simpleSlider('#slider' , true, 8000);
    });





